package Statistics;

import org.OPC_UA.OpcuaClient;
import org.eclipse.milo.opcua.stack.core.types.builtin.DataValue;

import java.util.Timer;
import java.util.TimerTask;

public class M11timer {
    //Se der é preciso adicionar o seguinte: Este private int NumberOfPieces e adicionar o acrestimo ao NumberOfPieces;
    //Adiciona o que tem este comentário "//***"
    private int NumberOfPieces = 0;//****

    public void M11_timer() {
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            int time = 0;
            int counter = 0;

            @Override
            public void run() {
                DataValue data = OpcuaClient.read("|var|CODESYS Control Win V3 x64.Application.PLC_PRG.M11.Process.x", 4);
                if (data.getValue().getValue() instanceof Boolean && (Boolean) data.getValue().getValue()) {
                    time++;
                }
            }
        };

        //Implementei agora botelho, consegues-me testar o código ligando ao UA expert?
        // Se não funcionar assim tenho que colocar uma flag dentro do if para quando a flag mudar ser acionado o counter
        // Increment NumberOfPieces by 1 when timer starts
        NumberOfPieces++;//****
        System.out.println(NumberOfPieces);

        timer.scheduleAtFixedRate(task, 0, 1000);
    }
}
