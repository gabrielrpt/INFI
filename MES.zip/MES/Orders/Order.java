package Orders;

public class Order {
    int priority;
    String type;
    
}
